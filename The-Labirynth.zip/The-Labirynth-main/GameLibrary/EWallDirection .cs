﻿namespace GameLibrary
{
    public enum EWallDirection
    {
        North,
        East,
        South,
        West
    }
}
