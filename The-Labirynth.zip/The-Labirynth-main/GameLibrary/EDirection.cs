﻿namespace GameLibrary
{
    public enum EDirection
    {
        North,
        East,
        South,
        West
    }
}
