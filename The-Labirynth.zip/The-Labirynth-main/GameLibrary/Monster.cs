﻿namespace GameLibrary
{
    public class Monster : Character
    {

    }
}
