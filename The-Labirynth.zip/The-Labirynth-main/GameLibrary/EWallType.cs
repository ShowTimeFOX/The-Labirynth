﻿namespace GameLibrary
{
    public enum EWallType
    {
        Solid,
        Empty,
        Door
    }
}
