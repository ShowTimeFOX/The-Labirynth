﻿namespace GameLibrary
{
    public class Player : Character
    {
        public Coordinates Coordinates { get; set; }
        public EDirection Direction { get; set; }

        
    }
}
