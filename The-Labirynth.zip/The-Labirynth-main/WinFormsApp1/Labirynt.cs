﻿namespace WinFormsApp1
{
    internal class Labirynt
    {
        public int MyProperty { get; set; }
        public Labirynt() { }

    }
}
